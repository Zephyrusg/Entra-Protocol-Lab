from flask import Blueprint, redirect, session, make_response
from flask.typing import ResponseReturnValue
from onelogin.saml2.utils import OneLogin_Saml2_Utils
from .settings import saml_auth, saml_settings
from ..utils.html import page, _pretty_json


bp = Blueprint("saml", __name__)

@bp.get("/login")
def login() -> ResponseReturnValue:
    auth = saml_auth()
    # RelayState to /saml/user to match your original flow
    return redirect(auth.login(return_to="/saml/user"))

@bp.post("/acs")
def acs() -> ResponseReturnValue:
    auth = saml_auth()
    auth.process_response()


    errors = auth.get_errors()
    if errors:
        return page(
            "SAML Error",
            f"<p>Errors: {errors}</p><pre>{auth.get_last_error_reason() or ''}</pre>",
         )
  
    if not auth.is_authenticated():
        return page("SAML Error", "<p>Not authenticated.</p>")
    

    # Minimal profile for demo
    data = {
        "nameid": auth.get_nameid(),
        "session_index": auth.get_session_index(),
        "attributes": auth.get_attributes(),
        "issuer": auth.get_issuer(),
        "authn_context": auth.get_authn_context(),
        }
    session["saml"] = data
    return redirect("/saml/user")

@bp.get("/user")
def user() -> ResponseReturnValue:
    data = session.get("saml")
    if not data:
        return page("SAML User", "<p>Not signed in. <a href='/saml/login'>Login</a></p>")


    body = "<h2>Attributes</h2><pre>" + _pretty_json(data.get("attributes", {})) + "</pre>"
    body += "<h2>Session</h2><pre>" + _pretty_json({
        k: v for k, v in data.items() if k != "attributes"
    }) + "</pre>"
    body += "<p><a href='/saml/logout'>SAML Logout</a></p>"
    return page("SAML User", body)

@bp.get("/logout")
def logout() -> ResponseReturnValue:
    data = session.get("saml") or {}
    nameid = data.get("nameid")
    session_index = data.get("session_index")


    auth = saml_auth()
    slo_url = auth.logout(name_id=nameid, session_index=session_index, return_to="/")
    return redirect(slo_url)    

@bp.get("/metadata")
def metadata() -> ResponseReturnValue:
    settings_obj = saml_settings()
    metadata = settings_obj.get_sp_metadata()
    errors = settings_obj.validate_metadata(metadata)
    if len(errors) > 0:
        return page("SAML Metadata Error", f"<pre>{errors}</pre>")


    resp = make_response(metadata, 200)
    resp.headers["Content-Type"] = "text/xml"
    # Helpful for Entra XML import
    resp.headers["Content-Disposition"] = "attachment; filename=sp-metadata.xml"
    return resp